#!/usr/bin/env node

require(process.env.JS_LIB_HOME + '/log')

log("Hello, ./log.js has been required!")