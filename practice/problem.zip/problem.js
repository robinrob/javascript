#!/usr/bin/env node

require('./required')

(function () {
    console.log("Hello World!")
})()